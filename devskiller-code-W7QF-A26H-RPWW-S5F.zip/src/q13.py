from typing import Dict, List


def solve(input: str) -> Dict[str, List[List[str]]]:
    return {}
